import express from "express";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import Database from "better-sqlite3";
import { z } from "zod";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-change-me";
const APP_URL = process.env.APP_URL || `http://localhost:${PORT}`;
const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY || "";
const EMAIL_FROM = process.env.EMAIL_FROM || "no-reply@boostwithme.local";
const FRONTEND_URL = process.env.FRONTEND_URL || APP_URL;
const ADMIN_NAME = process.env.ADMIN_NAME || "David Daniel";
const ADMIN_PHONE = process.env.ADMIN_PHONE || "08144594011";
const SUPPORT_EMAIL = process.env.SUPPORT_EMAIL || "boostwithme7@gmail.com";
const DOMAIN = process.env.DOMAIN || "boostwithme.com";

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cookieParser());
app.use(express.json({
  verify: (req, _res, buf) => { req.rawBody = buf; }
}));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));

// Lightweight in-memory abuse protection for authentication endpoints.
const authAttempts = new Map();
function authRateLimit(req, res, next) {
  const key = `${req.ip}:${req.path}`;
  const now = Date.now();
  const windowMs = 15 * 60 * 1000;
  const max = 12;
  const recent = (authAttempts.get(key) || []).filter(t => now - t < windowMs);
  if (recent.length >= max) return res.status(429).json({error:"Too many attempts. Please try again later."});
  recent.push(now); authAttempts.set(key, recent);
  next();
}

const db = new Database(path.join(__dirname, "boostwithme.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  email_verified_at TEXT,
  verification_token_hash TEXT,
  verification_expires_at TEXT,
  reset_token_hash TEXT,
  reset_expires_at TEXT
);
CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  platform TEXT NOT NULL,
  description TEXT NOT NULL,
  price_kobo INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  public_id TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL,
  service_id INTEGER NOT NULL,
  package_name TEXT NOT NULL,
  target_url TEXT NOT NULL,
  amount_kobo INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_payment',
  payment_reference TEXT UNIQUE,
  payment_status TEXT NOT NULL DEFAULT 'unpaid',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(service_id) REFERENCES services(id)
);
CREATE TABLE IF NOT EXISTS order_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL,
  status TEXT NOT NULL,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(order_id) REFERENCES orders(id)
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_user_id INTEGER,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id TEXT,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(actor_user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS support_tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

for (const stmt of [
  "ALTER TABLE users ADD COLUMN email_verified_at TEXT",
  "ALTER TABLE users ADD COLUMN verification_token_hash TEXT",
  "ALTER TABLE users ADD COLUMN verification_expires_at TEXT",
  "ALTER TABLE users ADD COLUMN reset_token_hash TEXT",
  "ALTER TABLE users ADD COLUMN reset_expires_at TEXT"
]) { try { db.exec(stmt); } catch {} }
const serviceCount = db.prepare("SELECT COUNT(*) AS c FROM services").get().c;
if (!serviceCount) {
  const seed = db.prepare("INSERT INTO services (name,platform,description,price_kobo) VALUES (?,?,?,?)");
  const rows = [
    ["Instagram Promotion","Instagram","Campaign support designed to increase qualified visibility and engagement.",500000],
    ["TikTok Promotion","TikTok","Promotion campaigns designed to improve content discovery and audience awareness.",500000],
    ["YouTube Promotion","YouTube","Campaign options for increasing video discovery and audience awareness.",750000],
    ["Facebook Promotion","Facebook","Social promotion packages for pages, brands and creators.",500000]
  ];
  const tx=db.transaction(()=>rows.forEach(r=>seed.run(...r))); tx();
}

function publicUser(u){ return {id:u.id,name:u.name,email:u.email,role:u.role}; }
function signToken(u){ return jwt.sign({id:u.id,role:u.role},JWT_SECRET,{expiresIn:"7d"}); }
function setAuth(res,u){
  res.cookie("bw_auth",signToken(u),{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7*24*60*60*1000});
}
function auth(req,res,next){
  try {
    const token=req.cookies.bw_auth;
    if(!token) return res.status(401).json({error:"Authentication required"});
    req.user=jwt.verify(token,JWT_SECRET);
    next();
  } catch { return res.status(401).json({error:"Invalid or expired session"}); }
}
function admin(req,res,next){
  if(req.user?.role!=="admin") return res.status(403).json({error:"Admin access required"});
  next();
}
function money(kobo){ return `₦${(kobo/100).toLocaleString("en-NG",{minimumFractionDigits:2})}`; }
function tokenHash(token){ return crypto.createHash("sha256").update(token).digest("hex"); }
function audit(actor,action,targetType,targetId,details=""){ db.prepare("INSERT INTO audit_logs(actor_user_id,action,target_type,target_id,details) VALUES(?,?,?,?,?)").run(actor?.id||null,action,targetType||null,String(targetId??""),details); }
async function sendEmail({to,subject,text}){
  const webhook=process.env.EMAIL_WEBHOOK_URL;
  if(!webhook) return {sent:false,reason:"EMAIL_WEBHOOK_URL not configured"};
  const r=await fetch(webhook,{method:"POST",headers:{"Content-Type":"application/json","X-Email-From":EMAIL_FROM},body:JSON.stringify({from:EMAIL_FROM,to,subject,text})});
  if(!r.ok) throw new Error("Email delivery failed");
  return {sent:true};
}

app.get("/api/health",(_req,res)=>res.json({ok:true,service:"BOOSTWITHME API"}));
app.get("/api/config",(_req,res)=>res.json({brand:"BOOSTWITHME",domain:DOMAIN,adminName:ADMIN_NAME,adminPhone:ADMIN_PHONE,supportEmail:SUPPORT_EMAIL}));

app.get("/api/services",(_req,res)=>{
  const services=db.prepare("SELECT id,name,platform,description,price_kobo FROM services WHERE active=1 ORDER BY id").all();
  res.json({services:services.map(s=>({...s,price:money(s.price_kobo)}))});
});

const signupSchema=z.object({
  name:z.string().min(2).max(80),
  email:z.string().email().max(200),
  password:z.string().min(8).max(100)
});
app.post("/api/auth/register",authRateLimit,async(req,res)=>{
  const parsed=signupSchema.safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:"Enter a valid name, email and password (8+ characters)."});
  const {name,email,password}=parsed.data;
  if(db.prepare("SELECT id FROM users WHERE email=?").get(email.toLowerCase()))
    return res.status(409).json({error:"An account with that email already exists."});
  const hash=await bcrypt.hash(password,12);
  const role=(process.env.ADMIN_EMAIL||"").toLowerCase()===email.toLowerCase()?"admin":"customer";
  const verificationToken=crypto.randomBytes(32).toString("hex");
  const info=db.prepare("INSERT INTO users(name,email,password_hash,role,verification_token_hash,verification_expires_at) VALUES(?,?,?,?,?,datetime('now','+24 hours'))").run(name,email.toLowerCase(),hash,role,tokenHash(verificationToken));
  const u=db.prepare("SELECT id,name,email,role FROM users WHERE id=?").get(info.lastInsertRowid);
  audit(u,"user.register","user",u.id);
  const verifyUrl=`${FRONTEND_URL}/api/auth/verify-email?token=${verificationToken}`;
  try { await sendEmail({to:u.email,subject:"Verify your BOOSTWITHME account",text:`Welcome to BOOSTWITHME. Verify your email: ${verifyUrl}`}); } catch {}
  setAuth(res,u); res.status(201).json({user:publicUser(u),emailVerificationRequired:true});
});

app.post("/api/auth/login",authRateLimit,async(req,res)=>{
  const parsed=z.object({email:z.string().email(),password:z.string().min(1)}).safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:"Invalid login details."});
  const u=db.prepare("SELECT * FROM users WHERE email=?").get(parsed.data.email.toLowerCase());
  if(!u || !(await bcrypt.compare(parsed.data.password,u.password_hash))) return res.status(401).json({error:"Invalid email or password."});
  setAuth(res,u); res.json({user:publicUser(u)});
});
app.get("/api/auth/verify-email",async(req,res)=>{
  const token=String(req.query.token||"");
  if(!token) return res.status(400).send("Invalid verification link.");
  const u=db.prepare("SELECT * FROM users WHERE verification_token_hash=? AND verification_expires_at>datetime('now')").get(tokenHash(token));
  if(!u) return res.status(400).send("This verification link is invalid or expired.");
  db.prepare("UPDATE users SET email_verified_at=CURRENT_TIMESTAMP,verification_token_hash=NULL,verification_expires_at=NULL WHERE id=?").run(u.id);
  audit(u,"user.email_verified","user",u.id);
  res.send("Email verified successfully. You can return to BOOSTWITHME and sign in.");
});
app.post("/api/auth/resend-verification",authRateLimit,async(req,res)=>{
  const email=String(req.body?.email||"").toLowerCase(); const u=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if(u && !u.email_verified_at){ const token=crypto.randomBytes(32).toString("hex"); db.prepare("UPDATE users SET verification_token_hash=?,verification_expires_at=datetime('now','+24 hours') WHERE id=?").run(tokenHash(token),u.id); const verifyUrl=`${FRONTEND_URL}/api/auth/verify-email?token=${token}`; try { await sendEmail({to:u.email,subject:"Verify your BOOSTWITHME account",text:`Verify your email: ${verifyUrl}`}); } catch {} }
  res.json({ok:true,message:"If the account exists and needs verification, a new verification link has been sent."});
});
app.post("/api/auth/request-password-reset",authRateLimit,async(req,res)=>{
  const email=String(req.body?.email||"").toLowerCase(); const u=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if(u){ const token=crypto.randomBytes(32).toString("hex"); db.prepare("UPDATE users SET reset_token_hash=?,reset_expires_at=datetime('now','+1 hour') WHERE id=?").run(tokenHash(token),u.id); const resetUrl=`${FRONTEND_URL}/?reset_token=${token}`; try { await sendEmail({to:u.email,subject:"Reset your BOOSTWITHME password",text:`Reset your password: ${resetUrl}`}); } catch {} }
  res.json({ok:true,message:"If that email exists, password-reset instructions have been sent."});
});
app.post("/api/auth/reset-password",authRateLimit,async(req,res)=>{
  const p=z.object({token:z.string().min(20),password:z.string().min(8).max(100)}).safeParse(req.body); if(!p.success) return res.status(400).json({error:"Invalid reset request."});
  const u=db.prepare("SELECT * FROM users WHERE reset_token_hash=? AND reset_expires_at>datetime('now')").get(tokenHash(p.data.token)); if(!u) return res.status(400).json({error:"Reset token is invalid or expired."});
  const hash=await bcrypt.hash(p.data.password,12); db.prepare("UPDATE users SET password_hash=?,reset_token_hash=NULL,reset_expires_at=NULL WHERE id=?").run(hash,u.id); audit(u,"user.password_reset","user",u.id); res.json({ok:true});
});
app.post("/api/auth/logout",(_req,res)=>{res.clearCookie("bw_auth");res.json({ok:true});});
app.get("/api/auth/me",auth,(req,res)=>{
  const u=db.prepare("SELECT id,name,email,role FROM users WHERE id=?").get(req.user.id);
  res.json({user:publicUser(u)});
});

const orderSchema=z.object({
  serviceId:z.coerce.number().int().positive(),
  packageName:z.string().min(2).max(80),
  targetUrl:z.string().url().max(500)
});
app.post("/api/orders",auth,(req,res)=>{
  const parsed=orderSchema.safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:"Choose a service, package and valid profile/content URL."});
  const s=db.prepare("SELECT * FROM services WHERE id=? AND active=1").get(parsed.data.serviceId);
  if(!s) return res.status(404).json({error:"Service not found."});
  const publicId="BW"+Date.now().toString(36).toUpperCase()+crypto.randomBytes(2).toString("hex").toUpperCase();
  const info=db.prepare("INSERT INTO orders(public_id,user_id,service_id,package_name,target_url,amount_kobo) VALUES(?,?,?,?,?,?)")
    .run(publicId,req.user.id,s.id,parsed.data.packageName,parsed.data.targetUrl,s.price_kobo);
  db.prepare("INSERT INTO order_events(order_id,status,note) VALUES(?,?,?)").run(info.lastInsertRowid,"pending_payment","Order created; awaiting payment.");
  const order=db.prepare(`SELECT o.public_id,o.package_name,o.target_url,o.amount_kobo,o.status,o.payment_status,o.created_at,s.name service_name,s.platform
                          FROM orders o JOIN services s ON s.id=o.service_id WHERE o.id=?`).get(info.lastInsertRowid);
  res.status(201).json({order:{...order,amount:money(order.amount_kobo)}});
});

app.get("/api/orders",auth,(req,res)=>{
  const orders=db.prepare(`SELECT o.public_id,o.package_name,o.target_url,o.amount_kobo,o.status,o.payment_status,o.payment_reference,o.created_at,o.updated_at,
                           s.name service_name,s.platform
                           FROM orders o JOIN services s ON s.id=o.service_id
                           WHERE o.user_id=? ORDER BY o.id DESC`).all(req.user.id);
  res.json({orders:orders.map(o=>({...o,amount:money(o.amount_kobo)}))});
});

app.get("/api/orders/:publicId",auth,(req,res)=>{
  const o=db.prepare(`SELECT o.*,s.name service_name,s.platform FROM orders o JOIN services s ON s.id=o.service_id WHERE o.public_id=? AND o.user_id=?`)
    .get(req.params.publicId,req.user.id);
  if(!o) return res.status(404).json({error:"Order not found"});
  const events=db.prepare("SELECT status,note,created_at FROM order_events WHERE order_id=? ORDER BY id").all(o.id);
  res.json({order:{...o,amount:money(o.amount_kobo),events}});
});

/* Paystack: server-side initialization. Amount is sent in the currency subunit.
   The secret key is never exposed to the browser. */
app.post("/api/payments/paystack/initialize",auth,async(req,res)=>{
  const parsed=z.object({publicId:z.string().min(4)}).safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:"Invalid order."});
  if(!PAYSTACK_SECRET_KEY) return res.status(503).json({error:"Payments are not configured yet. Add PAYSTACK_SECRET_KEY to .env."});
  const order=db.prepare(`SELECT o.*,u.email FROM orders o JOIN users u ON u.id=o.user_id WHERE o.public_id=? AND o.user_id=?`).get(parsed.data.publicId,req.user.id);
  if(!order) return res.status(404).json({error:"Order not found"});
  if(order.payment_status==="paid") return res.status(409).json({error:"This order is already paid."});
  const reference=`BW-${order.public_id}-${crypto.randomBytes(5).toString("hex")}`;
  const response=await fetch("https://api.paystack.co/transaction/initialize",{
    method:"POST",
    headers:{"Authorization":`Bearer ${PAYSTACK_SECRET_KEY}`,"Content-Type":"application/json"},
    body:JSON.stringify({email:order.email,amount:String(order.amount_kobo),currency:process.env.PAYSTACK_CURRENCY||"NGN",reference,callback_url:`${APP_URL}/payment/callback`,metadata:{order_public_id:order.public_id}})
  });
  const data=await response.json();
  if(!response.ok || !data.status) return res.status(502).json({error:data.message||"Unable to initialize payment"});
  db.prepare("UPDATE orders SET payment_reference=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(reference,order.id);
  res.json({authorization_url:data.data.authorization_url,access_code:data.data.access_code,reference});
});

app.get("/payment/callback",(_req,res)=>res.sendFile(path.join(__dirname,"public","payment-callback.html")));

app.get("/api/payments/paystack/verify",auth,async(req,res)=>{
  const reference=String(req.query.reference||"");
  if(!reference || !PAYSTACK_SECRET_KEY) return res.status(400).json({error:"Missing payment reference or payment configuration."});
  const order=db.prepare("SELECT * FROM orders WHERE payment_reference=? AND user_id=?").get(reference,req.user.id);
  if(!order) return res.status(404).json({error:"Payment reference not found."});
  const response=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{headers:{Authorization:`Bearer ${PAYSTACK_SECRET_KEY}`}});
  const data=await response.json();
  if(!response.ok || !data.status) return res.status(502).json({error:data.message||"Unable to verify payment."});
  const paid=data.data?.status==="success" && Number(data.data.amount)===Number(order.amount_kobo);
  if(paid && order.payment_status!=="paid"){
    db.transaction(()=>{
      db.prepare("UPDATE orders SET payment_status='paid',status='processing',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(order.id);
      db.prepare("INSERT INTO order_events(order_id,status,note) VALUES(?,?,?)").run(order.id,"processing","Payment verified from transaction callback.");
    })();
  }
  const fresh=db.prepare("SELECT public_id,status,payment_status FROM orders WHERE id=?").get(order.id);
  res.json({verified:paid,order:fresh});
});

/* Webhook verification: Paystack signs the raw event body with HMAC-SHA512. */
app.post("/api/payments/paystack/webhook",(req,res)=>{
  if(!PAYSTACK_SECRET_KEY) return res.sendStatus(200);
  const signature=String(req.headers["x-paystack-signature"]||"");
  const expected=crypto.createHmac("sha512",PAYSTACK_SECRET_KEY).update(req.rawBody).digest("hex");
  if(!signature || signature.length!==expected.length || !crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected))) return res.sendStatus(401);
  const event=req.body;
  if(event.event==="charge.success"){
    const d=event.data;
    const ref=d.reference;
    const order=db.prepare("SELECT * FROM orders WHERE payment_reference=?").get(ref);
    if(order && d.status==="success" && Number(d.amount)===Number(order.amount_kobo) && order.payment_status!=="paid"){
      db.transaction(()=>{
        db.prepare("UPDATE orders SET payment_status='paid',status='processing',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(order.id);
        db.prepare("INSERT INTO order_events(order_id,status,note) VALUES(?,?,?)").run(order.id,"processing","Payment verified; order is now processing.");
      })();
    }
  }
  res.sendStatus(200);
});

app.get("/api/support",auth,(req,res)=>{
  const tickets=db.prepare("SELECT id,subject,message,status,created_at FROM support_tickets WHERE user_id=? ORDER BY id DESC").all(req.user.id);
  res.json({tickets});
});

app.get("/api/admin/customers",auth,admin,(_req,res)=>{
  const customers=db.prepare(`SELECT u.id,u.name,u.email,u.role,u.created_at,
    COUNT(o.id) order_count, COALESCE(SUM(CASE WHEN o.payment_status='paid' THEN o.amount_kobo ELSE 0 END),0) spend_kobo
    FROM users u LEFT JOIN orders o ON o.user_id=u.id GROUP BY u.id ORDER BY u.id DESC`).all();
  res.json({customers:customers.map(c=>({...c,spend:money(c.spend_kobo)}))});
});

app.get("/api/admin/stats",auth,admin,(_req,res)=>{
  const totals=db.prepare(`SELECT COUNT(*) total_orders, COALESCE(SUM(CASE WHEN payment_status='paid' THEN amount_kobo ELSE 0 END),0) revenue_kobo, COUNT(DISTINCT user_id) customers, COUNT(CASE WHEN payment_status='paid' THEN 1 END) paid_orders FROM orders`).get();
  const counts=db.prepare(`SELECT status,COUNT(*) count FROM orders GROUP BY status`).all();
  const tickets=db.prepare(`SELECT COUNT(*) count FROM support_tickets WHERE status='open'`).get();
  res.json({stats:{...totals,revenue:money(totals.revenue_kobo),open_tickets:tickets.count,status_counts:Object.fromEntries(counts.map(x=>[x.status,x.count]))}});
});

app.patch("/api/admin/customers/:id/role",auth,admin,(req,res)=>{
  const p=z.object({role:z.enum(["customer","admin"])}).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:"Invalid role."});
  if(Number(req.params.id)===req.user.id && p.data.role!=="admin") return res.status(400).json({error:"You cannot remove your own admin access."});
  const info=db.prepare("UPDATE users SET role=? WHERE id=?").run(p.data.role,req.params.id);
  if(!info.changes) return res.status(404).json({error:"Customer not found."});
  audit(req.user,"admin.customer_role_changed","user",req.params.id,`role=${p.data.role}`); res.json({ok:true});
});

app.get("/api/admin/services",auth,admin,(_req,res)=>{
  const services=db.prepare("SELECT id,name,platform,description,price_kobo,active,created_at FROM services ORDER BY id").all();
  res.json({services:services.map(s=>({...s,price:money(s.price_kobo)}))});
});
const serviceAdminSchema=z.object({name:z.string().min(2).max(100),platform:z.string().min(2).max(40),description:z.string().min(5).max(500),priceKobo:z.coerce.number().int().positive(),active:z.coerce.boolean().optional()});
app.post("/api/admin/services",auth,admin,(req,res)=>{
  const p=serviceAdminSchema.safeParse(req.body); if(!p.success) return res.status(400).json({error:"Enter valid service details."});
  const x=p.data; const info=db.prepare("INSERT INTO services(name,platform,description,price_kobo,active) VALUES(?,?,?,?,?)").run(x.name,x.platform,x.description,x.priceKobo,x.active===false?0:1);
  audit(req.user,"admin.service_created","service",info.lastInsertRowid); res.status(201).json({id:info.lastInsertRowid});
});
app.patch("/api/admin/services/:id",auth,admin,(req,res)=>{
  const p=serviceAdminSchema.partial().safeParse(req.body); if(!p.success) return res.status(400).json({error:"Invalid service details."});
  const cur=db.prepare("SELECT * FROM services WHERE id=?").get(req.params.id); if(!cur) return res.status(404).json({error:"Service not found"});
  const x=p.data; db.prepare("UPDATE services SET name=?,platform=?,description=?,price_kobo=?,active=? WHERE id=?").run(x.name??cur.name,x.platform??cur.platform,x.description??cur.description,x.priceKobo??cur.price_kobo,x.active===undefined?cur.active:(x.active?1:0),cur.id);
  audit(req.user,"admin.service_updated","service",cur.id); res.json({ok:true});
});

app.get("/api/admin/tickets",auth,admin,(_req,res)=>{
  const tickets=db.prepare(`SELECT t.id,t.subject,t.message,t.status,t.created_at,u.name customer_name,u.email FROM support_tickets t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC`).all();
  res.json({tickets});
});
const ticketStatusSchema=z.object({status:z.enum(["open","in_progress","closed"])});
app.patch("/api/admin/tickets/:id",auth,admin,(req,res)=>{
  const p=ticketStatusSchema.safeParse(req.body); if(!p.success) return res.status(400).json({error:"Invalid ticket status."});
  const info=db.prepare("UPDATE support_tickets SET status=? WHERE id=?").run(p.data.status,req.params.id); if(!info.changes) return res.status(404).json({error:"Ticket not found"});
  audit(req.user,"admin.ticket_updated","ticket",req.params.id,`status=${p.data.status}`); res.json({ok:true});
});

app.get("/api/admin/audit-logs",auth,admin,(req,res)=>{
  const limit=Math.min(Number(req.query.limit||100),500);
  const logs=db.prepare(`SELECT a.id,a.action,a.target_type,a.target_id,a.details,a.created_at,u.name actor_name,u.email actor_email FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_user_id ORDER BY a.id DESC LIMIT ?`).all(limit);
  res.json({logs});
});

app.get("/api/admin/orders",auth,admin,(_req,res)=>{
  const orders=db.prepare(`SELECT o.public_id,o.amount_kobo,o.status,o.payment_status,o.payment_reference,o.created_at,
                           u.name customer_name,u.email,s.name service_name
                           FROM orders o JOIN users u ON u.id=o.user_id JOIN services s ON s.id=o.service_id
                           ORDER BY o.id DESC`).all();
  res.json({orders:orders.map(o=>({...o,amount:money(o.amount_kobo)}))});
});

const statusSchema=z.object({status:z.enum(["pending_payment","processing","in_progress","completed","cancelled","refunded"]),note:z.string().max(500).optional()});
app.patch("/api/admin/orders/:publicId/status",auth,admin,(req,res)=>{
  const parsed=statusSchema.safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:"Invalid status."});
  const order=db.prepare("SELECT * FROM orders WHERE public_id=?").get(req.params.publicId);
  if(!order) return res.status(404).json({error:"Order not found"});
  db.transaction(()=>{
    db.prepare("UPDATE orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(parsed.data.status,order.id);
    db.prepare("INSERT INTO order_events(order_id,status,note) VALUES(?,?,?)").run(order.id,parsed.data.status,parsed.data.note||"Status updated by admin.");
  })();
  audit(req.user,"admin.order_status_changed","order",order.public_id,`status=${parsed.data.status}`); res.json({ok:true});
});

const ticketSchema=z.object({subject:z.string().min(2).max(120),message:z.string().min(5).max(2000)});
app.post("/api/support",auth,(req,res)=>{
  const p=ticketSchema.safeParse(req.body);
  if(!p.success) return res.status(400).json({error:"Please enter a subject and message."});
  const info=db.prepare("INSERT INTO support_tickets(user_id,subject,message) VALUES(?,?,?)").run(req.user.id,p.data.subject,p.data.message);
  res.status(201).json({ticketId:info.lastInsertRowid});
});

app.get(/.*/,(req,res)=>{
  if(req.path.startsWith("/api/")) return res.status(404).json({error:"Not found"});
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT,()=>console.log(`BOOSTWITHME running at ${APP_URL}`));
