# BOOSTWITHME production cutover

## Current state
The V3 application remains SQLite-backed for local development. It now includes account verification/reset flows, audit logs, stronger admin operations, Paystack verification/webhooks, and container/deployment configuration.

## Required before taking real traffic
1. Configure the intended domain `boostwithme.com`, admin email `danyellsdave7@gmail.com`, admin contact `08144594011`, and support email `boostwithme7@gmail.com`.
2. Complete the SQLite -> PostgreSQL application migration using `database/postgresql_schema.sql` as the target model.
3. Remove `ADMIN_EMAIL` bootstrap and provision admins explicitly.
4. Configure HTTPS, a strong `JWT_SECRET`, Paystack live credentials, and a real email delivery bridge.
5. Configure persistent database backups and application logs.
6. Add rate limiting backed by a shared store for multi-instance deployments.
7. Verify Paystack webhook delivery and reconciliation in production.
8. Add provider-specific fulfillment adapters only for legitimate promotional/marketing services that comply with each platform's rules.
9. Publish terms, privacy, refund, and acceptable-use policies.
